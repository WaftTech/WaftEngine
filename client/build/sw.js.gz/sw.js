var __wpo = {
  "assets": {
    "main": [
      "/favicon.ico",
      "/3f74ca0a6683918ec3a0b301aef078e7.svg",
      "/runtime~main.6d2782b714f3d59707df.js",
      "/"
    ],
    "additional": [
      "/vendor.dcacaf6d2b7a005ab02e.chunk.js",
      "/1.10ae21c39b9df9d3bf5c.chunk.js",
      "/2.947e87f088a016f3ac22.chunk.js",
      "/3.33b4c0f4552ced14e895.chunk.js",
      "/4.b811718e59e7a5ff09aa.chunk.js",
      "/5.23009a52f0ce4b357ff1.chunk.js",
      "/6.e4a0e06e426bbad0e1d5.chunk.js",
      "/7.254a4c8cb1f21f962203.chunk.js",
      "/8.8ff189fa652440b285e6.chunk.js",
      "/9.d1f50f31afbbdcb556bd.chunk.js",
      "/10.9768b0d4e51791aaf703.chunk.js",
      "/11.c1e9df45e85c3222594a.chunk.js",
      "/12.aa8606b2484735dafebc.chunk.js",
      "/13.d9d89cbb3b8897c11a2b.chunk.js",
      "/14.5642efb7d291b4782a79.chunk.js",
      "/15.ab3d50f0e54d0fec10a9.chunk.js",
      "/16.82e3f89e2f330553f8c2.chunk.js",
      "/main.d271d63c6f212aed292c.chunk.js",
      "/19.62217f798715c2717f94.chunk.js",
      "/20.f203ed4b8e57cd51b32d.chunk.js",
      "/21.220f43fbda0697193127.chunk.js",
      "/22.55020d072acfaa257cb6.chunk.js",
      "/23.218c22c5ebe8f5f1a216.chunk.js",
      "/24.03acc398b6622c672160.chunk.js",
      "/25.13df152ffa80ea5cd211.chunk.js",
      "/26.a4b2b1129646ba15dfd3.chunk.js",
      "/27.514ffa0bcd78ecae840f.chunk.js",
      "/28.c5c36fe93127e378ec1c.chunk.js",
      "/29.35ad51a9e47115a8bcaf.chunk.js",
      "/30.8a695a5bff8061e8d837.chunk.js",
      "/31.ef2bf4471a442ade7eec.chunk.js",
      "/32.0dec48967d0ae4f27e84.chunk.js",
      "/33.59b11681c92a814cac80.chunk.js",
      "/34.45fb0717400e93249234.chunk.js",
      "/35.6fad14d656b9458387f6.chunk.js",
      "/36.5bc268f9b7bc66df7d78.chunk.js",
      "/37.5f4e0a50dc5a5821c1c9.chunk.js",
      "/38.d1b899ed79caa1454e74.chunk.js",
      "/39.62abe69e1d23c0d552dd.chunk.js",
      "/40.feadfe5874538632bcd3.chunk.js",
      "/41.45ec113e3bf6fd2937cf.chunk.js",
      "/42.414dc24d8745a38b634b.chunk.js",
      "/43.a4d174273c79fb95afba.chunk.js",
      "/44.ba823568865c83320e6a.chunk.js",
      "/45.525c3624efde3dbf6282.chunk.js",
      "/46.ece5d349d2abf1942490.chunk.js",
      "/47.82519f92f948a17e68ac.chunk.js",
      "/48.0b32eac29ccc5a11ddcf.chunk.js",
      "/49.3abad190ddb7569274b2.chunk.js",
      "/50.ef0fb41c29cb531a25ed.chunk.js",
      "/51.bc7d7a7072d7d9db586b.chunk.js",
      "/52.636405651a49628b6d49.chunk.js",
      "/53.29a194b7b019749689d3.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "c167dc53a9619105b73cdd19d37d94c6c6622f60": "/favicon.ico",
    "3762b667b6f3c30271102a466b209309eb7b38d7": "/3f74ca0a6683918ec3a0b301aef078e7.svg",
    "9a4d0fdf59d3097aa74132d6de7f79af38f07a9d": "/vendor.dcacaf6d2b7a005ab02e.chunk.js",
    "13a343c1b2b7d677268d3a81c18ef7e41a8bbc94": "/1.10ae21c39b9df9d3bf5c.chunk.js",
    "b8cc2f5f2fd979ced9c280e9d8eab20fdd7f28cf": "/2.947e87f088a016f3ac22.chunk.js",
    "8ee49cc1ab7a7d3ec6d3b08c73c50ea422d24502": "/3.33b4c0f4552ced14e895.chunk.js",
    "8cc01e105a62c7122fd1c7e1c12f72d2a3706b6d": "/4.b811718e59e7a5ff09aa.chunk.js",
    "2254a1d43e42ca9ed3678409f4397c3b5605f226": "/5.23009a52f0ce4b357ff1.chunk.js",
    "4cc4c9c5d9b084e1419cf0835d72a753a9e1d925": "/6.e4a0e06e426bbad0e1d5.chunk.js",
    "55f948250676d1b4c460c29ca4d048144f49756f": "/7.254a4c8cb1f21f962203.chunk.js",
    "872a55c0ac67165f382ec489bd2018ecce2639c6": "/8.8ff189fa652440b285e6.chunk.js",
    "7e26feeb8440804f783e9a89f63ef8a1d97c26b8": "/9.d1f50f31afbbdcb556bd.chunk.js",
    "44ea31865f057c6914b2bb00e9d44c842a43b10e": "/10.9768b0d4e51791aaf703.chunk.js",
    "d0bc7d17801f6658dd840ab09007c884ebd79b7a": "/11.c1e9df45e85c3222594a.chunk.js",
    "1193ab6d33440dfcef1d817faef61eae849db4c7": "/12.aa8606b2484735dafebc.chunk.js",
    "2599c25d0cebf94ae46df6c1566ac3ea550a9c10": "/13.d9d89cbb3b8897c11a2b.chunk.js",
    "495e081232eaed859319eb4c8c1f3b11f5026d7b": "/14.5642efb7d291b4782a79.chunk.js",
    "8fb97be5c84b4c8b77f8c58f9523ede37ebc8f3b": "/15.ab3d50f0e54d0fec10a9.chunk.js",
    "8e5027be96e0424f91c3830366aaa6af110246ed": "/16.82e3f89e2f330553f8c2.chunk.js",
    "a84c5f1a11960d4416d7b95adff22cbd29c5cfaa": "/main.d271d63c6f212aed292c.chunk.js",
    "44118b87ecc342429c2d8f20ae1cd7c4646b724d": "/runtime~main.6d2782b714f3d59707df.js",
    "7f23ce0fb7cbabe7a7506558abe42009bb8fdd9f": "/19.62217f798715c2717f94.chunk.js",
    "01e3cbe2f11e9c5f21f26e6c9981bd321529c291": "/20.f203ed4b8e57cd51b32d.chunk.js",
    "4d031304e364090605e52a1065c96988f647fbb6": "/21.220f43fbda0697193127.chunk.js",
    "9278479ae0e430790da3f893dcac4278f5c0542a": "/22.55020d072acfaa257cb6.chunk.js",
    "555b7b5dab7766e9c1303972f35f8baab80fe4e9": "/23.218c22c5ebe8f5f1a216.chunk.js",
    "3e7911592c70cc5ef46d9364c86928bcc1df1021": "/24.03acc398b6622c672160.chunk.js",
    "e40a5685c7998f234bb66bb29b9cd250d84ff60f": "/25.13df152ffa80ea5cd211.chunk.js",
    "fd5489268b8edcafb3da91bf97c2a5265d562f2c": "/26.a4b2b1129646ba15dfd3.chunk.js",
    "4fa0f585866256fce5e4904e8bcdf1c43c7bf0df": "/27.514ffa0bcd78ecae840f.chunk.js",
    "acd10cc3be52abd95dd64fba6137e2f6b9cbb628": "/28.c5c36fe93127e378ec1c.chunk.js",
    "70c493702a4d911c9c74b15446a22ac732e09cb8": "/29.35ad51a9e47115a8bcaf.chunk.js",
    "7422157c8ccc20cacf59a399099b91c76cadc5b6": "/30.8a695a5bff8061e8d837.chunk.js",
    "a7795729980b7c8ab2d06c815b06ddf8d4f14aa9": "/31.ef2bf4471a442ade7eec.chunk.js",
    "551a17dfe9f4ced468004471cc05d322f38a459d": "/32.0dec48967d0ae4f27e84.chunk.js",
    "a63fde13dc763b2272aaa6783b30bd2ad9817eaa": "/33.59b11681c92a814cac80.chunk.js",
    "13ce3ec29f7a9fa0a5b5f0baa977989540dc828d": "/34.45fb0717400e93249234.chunk.js",
    "fe7b96f2caac7b80eac737df9843b9fa295c483b": "/35.6fad14d656b9458387f6.chunk.js",
    "8f49e3460f392d72f5474cd8d8cb06cfcdb30859": "/36.5bc268f9b7bc66df7d78.chunk.js",
    "fe40d335228a390fd10a12e82ed226d5c22b178c": "/37.5f4e0a50dc5a5821c1c9.chunk.js",
    "5cfa33834b8d1e1391d65205ed3a80b0a87e9ac3": "/38.d1b899ed79caa1454e74.chunk.js",
    "54adfb4f8d2551797f3b9a3e76f39ac4e8c25636": "/39.62abe69e1d23c0d552dd.chunk.js",
    "cd66b6ff5eb2affd3f5c67f95061bea8956f3657": "/40.feadfe5874538632bcd3.chunk.js",
    "2234d90640a7b1a2137c0d228da0b39d1c5a3836": "/41.45ec113e3bf6fd2937cf.chunk.js",
    "cf3a640547cab91e8d8e9e333a3a5f335f1edad8": "/42.414dc24d8745a38b634b.chunk.js",
    "6579230767bbef424a220044839320eaa4420bf4": "/43.a4d174273c79fb95afba.chunk.js",
    "adafe658219c102d51fbca7d24cdb0f233f2eebd": "/44.ba823568865c83320e6a.chunk.js",
    "c60190f2fb1ec3bdb0c87a826d03b114725c3881": "/45.525c3624efde3dbf6282.chunk.js",
    "19fc6105ca12b6a54d2c68a3ecba27967682b35e": "/46.ece5d349d2abf1942490.chunk.js",
    "2ce39255ee9f6f6f766d6bf354e19b7773092851": "/47.82519f92f948a17e68ac.chunk.js",
    "a844e66d533d66d60d4ad7fb403162cb3ade062a": "/48.0b32eac29ccc5a11ddcf.chunk.js",
    "cede1ad01f601fd196cf8393c3b90f4610c3e329": "/49.3abad190ddb7569274b2.chunk.js",
    "4c92a141b8ac1cd0801b98ba1f5154a2b6c055c7": "/50.ef0fb41c29cb531a25ed.chunk.js",
    "25899a47cf7f4d6f44de4b2dcb672c6511919764": "/51.bc7d7a7072d7d9db586b.chunk.js",
    "01bfbfe489bbca4dfacb177ff53ad70bc537dee4": "/52.636405651a49628b6d49.chunk.js",
    "6b40272007033caaa289ceec9ea37ad151478a25": "/53.29a194b7b019749689d3.chunk.js",
    "ceae946c15e43f27b11fa55a191439ea70a11725": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "5/14/2019, 2:40:19 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });